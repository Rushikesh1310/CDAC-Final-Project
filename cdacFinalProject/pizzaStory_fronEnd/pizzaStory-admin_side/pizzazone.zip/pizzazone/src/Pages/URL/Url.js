const URL =`http://localhost:7071/`
export default URL