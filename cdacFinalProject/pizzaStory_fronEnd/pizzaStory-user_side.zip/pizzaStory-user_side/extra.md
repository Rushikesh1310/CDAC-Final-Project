cartId: 1
cartstatus: 0
itemsize:
item:
      description: "pizza, dish of Italian origin consisting of a flattened disk of bread dough"
      itemName: "Momo Mia Pizza"
      itemid: 11
      type: "Veg"
price: 250
size: "Regular"
sizeId: 16

payId:
    address:
    addressId: 17
    city: "NGP"
    district: "NGP"
    pincode: "441111"
    plotNo: "type D/22/02"
    soverignState: "Mh"
    streetName: "koradi colony"

deliveryId: 12
    deliveryStatus: "Order Received"
    deliveryTime: "2022-04-07T16:13:52.000+00:00"
    payments:
        mode: "Card Payment"
        payId: 72
        payStatus: "success"
        payTimeStamp: "2022-04-07T16:13:52.000+00:00"
        totalAmount: 730

[[Prototype]]: Object
[[Prototype]]: Object

[[Prototype]]: Object
[[Prototype]]: Object
price: 250
quantity: 1
toppings: null